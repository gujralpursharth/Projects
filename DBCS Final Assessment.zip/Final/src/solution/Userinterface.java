package solution;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Userinterface {

	/**********************************************************************************************
	 * 
	 * Attributes
	 * 
	 **********************************************************************************************/

	/*
	 * Constants used to parameterize the graphical user interface. We do not use a
	 * layout manager for this application. Rather we manually control the location
	 * of each graphical element for exact control of the look and feel.
	 */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;

	// These are the application values required by the user interface
	private Label label_Doublemainline = new Label("Admin Function");

	
	
	private Button ind_score = new Button(" Submit Data");
	private Button student = new Button(" Student Details");
	
	TextField DataSource1 = new TextField();
	TextField DataSource2 = new TextField();

	private double buttonSpace;

	public Userinterface(Pane theRoot, Stage Stage) {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		// Label theScene with the name of the mainline, centered at the top of the pane
		setupLabelUI(label_Doublemainline, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		// Button UI
		setupButtonUI(ind_score, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET,
				300);
		
		setupButtonUI(student, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET+ 150,
				100);

		DataSource1.setLayoutX(300);
		DataSource1.setLayoutY(200);
		
		
		
;		DataSource2.setLayoutX(300);
		DataSource2.setLayoutY(100);

		
		student.setOnAction((event) -> {
		try {
			submission();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		}
	);

		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_Doublemainline, ind_score,DataSource1,DataSource2,student);

	}
	
	

	private void submission() throws SQLException, ClassNotFoundException {
		
		
		
				String url = "jdbc:mysql://localhost:3306/";
				String uName = "root";
				String pass = "309919";
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection(url, uName, pass);
				PreparedStatement st = con.prepareStatement("create database lifme11");
				
				
				st.executeUpdate();
				System.out.println("a");
				st.close();
				con.close();
			}
		

	




	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * User Interface Actions
	 * 
	 **********************************************************************************************/

	
}